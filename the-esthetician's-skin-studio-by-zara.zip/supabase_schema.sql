-- =========================================================
-- THE ESTHETICIAN'S SKIN STUDIO BY ZARA — SUPABASE SCHEMA
-- Project ID: vulpskpdddnrptmudbjj
-- =========================================================

-- 1. Create the appointments table
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  service_id TEXT NOT NULL,
  service_title TEXT NOT NULL,
  preferred_date TEXT NOT NULL,
  preferred_time TEXT NOT NULL,
  skin_concerns TEXT DEFAULT '',
  confirmation_code TEXT NOT NULL,
  status TEXT DEFAULT 'pending'
);

-- 2. Enable Row Level Security (RLS)
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- 3. Policy: Allow website visitors to insert their appointment requests
CREATE POLICY "Allow public insert for appointments"
ON public.appointments
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- 4. Policy: Allow reading appointments (for studio management)
CREATE POLICY "Allow read appointments"
ON public.appointments
FOR SELECT
TO anon, authenticated
USING (true);

-- 5. Optional Index for fast querying by date and status
CREATE INDEX IF NOT EXISTS idx_appointments_created_at ON public.appointments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON public.appointments(status);
