import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://vulpskpdddnrptmudbjj.supabase.co';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Jskvg1IsP-KfY7FHJic-Og_E-IwFOJj';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export interface AppointmentRecord {
  id?: string;
  created_at?: string;
  full_name: string;
  phone: string;
  service_id: string;
  service_title: string;
  preferred_date: string;
  preferred_time: string;
  skin_concerns?: string;
  confirmation_code: string;
  status?: string;
}

/**
 * Saves a new appointment record into the Supabase `appointments` table.
 */
export async function saveAppointmentToSupabase(appointment: AppointmentRecord): Promise<{ success: boolean; data?: any; error?: any }> {
  try {
    const { data, error } = await supabase
      .from('appointments')
      .insert([
        {
          full_name: appointment.full_name,
          phone: appointment.phone,
          service_id: appointment.service_id,
          service_title: appointment.service_title,
          preferred_date: appointment.preferred_date,
          preferred_time: appointment.preferred_time,
          skin_concerns: appointment.skin_concerns || '',
          confirmation_code: appointment.confirmation_code,
          status: appointment.status || 'pending',
          created_at: new Date().toISOString()
        }
      ])
      .select();

    if (error) {
      console.warn('Supabase insert warning / error:', error.message || error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (err) {
    console.error('Failed to save appointment to Supabase:', err);
    return { success: false, error: err };
  }
}
