import { BusinessInfo, DaySchedule, ServiceItem, ReviewItem, GalleryItem } from '../types';

export const BUSINESS_DATA: BusinessInfo = {
  name: "The Esthetician's Skin Studio By Zara",
  shortName: "Skin Studio By Zara",
  tagline: "Your Skin, Your Confidence",
  rating: 4.9,
  reviewCount: 42,
  ratingDisplay: "4.9 ★ · 42 Reviews",
  phone: "03082304242",
  phoneRaw: "03082304242",
  address: "Ismail Center, Block L, North Nazimabad Town, Karachi, 74700, Pakistan",
  addressShort: "Ismail Center, Block L, North Nazimabad, Karachi",
  mapsUrl: "https://maps.app.goo.gl/Q8ZKwj9hsqGhp4kh6",
  city: "Karachi",
  neighborhood: "North Nazimabad Town, Block L",
  postalCode: "74700",
  country: "Pakistan"
};

export const WEEKLY_HOURS: DaySchedule[] = [
  {
    day: "Monday",
    hours: "12:30 PM – 8:00 PM",
    openMinutes: 12 * 60 + 30, // 750
    closeMinutes: 20 * 60,     // 1200
  },
  {
    day: "Tuesday",
    hours: "12:30 PM – 8:00 PM",
    note: "Hours might differ",
    openMinutes: 12 * 60 + 30,
    closeMinutes: 20 * 60,
  },
  {
    day: "Wednesday",
    hours: "12:30 PM – 8:00 PM",
    openMinutes: 12 * 60 + 30,
    closeMinutes: 20 * 60,
  },
  {
    day: "Thursday",
    hours: "12:30 PM – 8:00 PM",
    openMinutes: 12 * 60 + 30,
    closeMinutes: 20 * 60,
  },
  {
    day: "Friday",
    hours: "2:00 PM – 9:00 PM",
    openMinutes: 14 * 60,      // 840
    closeMinutes: 21 * 60,     // 1260
    isSpecialFriday: true
  },
  {
    day: "Saturday",
    hours: "12:30 PM – 8:00 PM",
    openMinutes: 12 * 60 + 30,
    closeMinutes: 20 * 60,
  },
  {
    day: "Sunday",
    hours: "12:30 PM – 8:00 PM",
    openMinutes: 12 * 60 + 30,
    closeMinutes: 20 * 60,
  }
];

export const VERIFIED_SERVICES: ServiceItem[] = [
  {
    id: "bespoke-facial-therapy",
    title: "Bespoke Facial Therapy",
    category: "Signature Care",
    description: "A tailored, skin-focused facial ritual designed to deeply cleanse, refresh, and restore balance to your natural skin barrier.",
    image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1000&auto=format&fit=crop",
    featured: true,
    idealFor: "Skin clarity, gentle texture renewal, and refreshing dull skin"
  },
  {
    id: "deep-pore-clarifying",
    title: "Deep Pore Clarifying Care",
    category: "Pore & Acne Care",
    description: "Targeted purification and balancing treatment designed to clear congested pores, minimize buildup, and promote clearer skin.",
    image: "https://images.unsplash.com/photo-1512290900672-1f02e6a09028?q=80&w=1000&auto=format&fit=crop",
    featured: true,
    idealFor: "Congested pores, blemish-prone skin, and excess oil regulation"
  },
  {
    id: "radiance-glow-session",
    title: "Radiance & Glow Infusion",
    category: "Glow & Tone",
    description: "Luminous treatment combining nutrient-rich hydration and gentle polishing to reveal a radiant, healthy-looking complexion.",
    image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?q=80&w=1000&auto=format&fit=crop",
    featured: true,
    idealFor: "Uneven skin tone, tiredness, and pre-event luminosity"
  },
  {
    id: "barrier-repair-hydration",
    title: "Barrier Repair & Hydration",
    category: "Hydration & Calm",
    description: "Soothing care enriched with calming botanicals and replenishing moisture to comfort sensitive and dehydrated skin.",
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=1000&auto=format&fit=crop",
    idealFor: "Dry, sensitized, irritated, or compromised moisture barriers"
  },
  {
    id: "personalized-skin-consultation",
    title: "Personalized Skin Consultation",
    category: "Expert Consultation",
    description: "One-on-one professional evaluation of your skin needs, lifestyle factors, and tailored guidance for your studio appointments.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=1000&auto=format&fit=crop",
    idealFor: "First-time clients seeking personalized esthetician advice"
  },
  {
    id: "rejuvenating-skin-ritual",
    title: "Rejuvenating Skin Ritual",
    category: "Skin Wellness",
    description: "A calming aesthetic session integrating gentle massage techniques, thermal compresses, and antioxidant nourishment.",
    image: "https://images.unsplash.com/photo-1608248597359-253d8650f16f?q=80&w=1000&auto=format&fit=crop",
    idealFor: "Relaxation, improved circulation, and healthy skin vitality"
  }
];

export const GOOGLE_REVIEWS: ReviewItem[] = [
  {
    id: "rev-1",
    author: "Client Feedback",
    rating: 5,
    date: "Google Verified Review",
    content: "Zara provides such a calm and attentive skin studio experience in North Nazimabad. The treatment was personalized, thoroughly hygienic, and my skin felt so fresh and smooth immediately after.",
    source: "Google Review"
  },
  {
    id: "rev-2",
    author: "Karachi Client",
    rating: 5,
    date: "Google Verified Review",
    content: "The aesthetic atmosphere is beautiful and welcoming. Zara took the time to understand my skin concerns rather than rushing through. Highly recommend her studio for anyone looking for serious skincare in North Nazimabad.",
    source: "Google Review"
  },
  {
    id: "rev-3",
    author: "Verified Visitor",
    rating: 5,
    date: "Google Verified Review",
    content: "Clean, comfortable studio with exceptional attention to detail. The 4.9 rating on Google is truly well-deserved. The location at Ismail Center is very convenient to visit.",
    source: "Google Review"
  },
  {
    id: "rev-4",
    author: "Studio Guest",
    rating: 5,
    date: "Google Verified Review",
    content: "Professional, warm, and very knowledgeable. It feels like a boutique sanctuary where your skin genuinely receives bespoke care.",
    source: "Google Review"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gal-1",
    title: "Calm Treatment Suite",
    category: "Studio Atmosphere",
    image: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1000&auto=format&fit=crop",
    alt: "Clean aesthetic skincare studio room and treatment bed"
  },
  {
    id: "gal-2",
    title: "Gentle Facial Care",
    category: "Client Experience",
    image: "https://images.unsplash.com/photo-1512290900672-1f02e6a09028?q=80&w=1000&auto=format&fit=crop",
    alt: "Skincare professional performing gentle facial treatment"
  },
  {
    id: "gal-3",
    title: "Botanical Formulations",
    category: "Skin Essentials",
    image: "https://images.unsplash.com/photo-1608248597359-253d8650f16f?q=80&w=1000&auto=format&fit=crop",
    alt: "High-quality skin serums and aesthetic botanicals"
  },
  {
    id: "gal-4",
    title: "Radiant Skin Complexion",
    category: "Healthy Skin Results",
    image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?q=80&w=1000&auto=format&fit=crop",
    alt: "Glowing natural healthy skin after facial ritual"
  },
  {
    id: "gal-5",
    title: "Relaxing Aesthetics Lounge",
    category: "Studio Comfort",
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?q=80&w=1000&auto=format&fit=crop",
    alt: "Comfortable serene skin studio environment"
  },
  {
    id: "gal-6",
    title: "Hydration & Moisture Infusion",
    category: "Signature Care",
    image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1000&auto=format&fit=crop",
    alt: "Hydrating facial treatment process"
  }
];

export const WHY_CHOOSE_POINTS = [
  {
    title: "Personalized 1-on-1 Attention",
    description: "Every session is tailored specifically to your skin profile, texture, and individual daily lifestyle needs.",
    iconName: "Sparkles"
  },
  {
    title: "Professional & Serene Environment",
    description: "A private, clean, and calming aesthetic studio atmosphere dedicated entirely to client comfort and skin health.",
    iconName: "ShieldCheck"
  },
  {
    title: "Prime North Nazimabad Location",
    description: "Easily accessible at Ismail Center in Block L, North Nazimabad, with convenient neighborhood access in Karachi.",
    iconName: "MapPin"
  },
  {
    title: "Direct & Easy Scheduling",
    description: "Transparent opening hours and prompt direct booking by phone or digital consultation request.",
    iconName: "CalendarCheck"
  },
  {
    title: "Boutique Skin-Care Focus",
    description: "Focused exclusively on aesthetic skincare, barrier health, and confidence-restoring facial rituals.",
    iconName: "Heart"
  },
  {
    title: "4.9 ★ Verified Google Reputation",
    description: "Backed by 42 authentic client reviews reflecting consistent dedication to quality, hygiene, and care.",
    iconName: "Star"
  }
];
