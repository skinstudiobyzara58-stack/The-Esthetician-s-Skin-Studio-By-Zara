import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { AboutStudio } from './components/AboutStudio';
import { ServicesSection } from './components/ServicesSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ReviewsSection } from './components/ReviewsSection';
import { GallerySection } from './components/GallerySection';
import { LocationSection } from './components/LocationSection';
import { OpeningHoursSection } from './components/OpeningHoursSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { MobileActionBar } from './components/MobileActionBar';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedServiceId, setSelectedServiceId] = useState<string | undefined>();

  const handleOpenBooking = (serviceId?: string) => {
    setSelectedServiceId(serviceId);
    setBookingModalOpen(true);
  };

  const handleCloseBooking = () => {
    setBookingModalOpen(false);
    setSelectedServiceId(undefined);
  };

  return (
    <div className="min-h-screen bg-[#F7F3EE] text-[#332824] flex flex-col selection:bg-[#8FA58B]/20 selection:text-[#332824]">
      {/* Sticky Header */}
      <Header onOpenBooking={handleOpenBooking} />

      {/* Main Content Area */}
      <main className="flex-grow">
        {/* 01: Hero Section */}
        <Hero onOpenBooking={() => handleOpenBooking()} />

        {/* 02: 4.9 ★ / 42 Reviews Trust Strip */}
        <TrustStrip />

        {/* 03: About The Studio */}
        <AboutStudio onOpenBooking={() => handleOpenBooking()} />

        {/* 04: Featured Services Grid */}
        <ServicesSection onOpenBooking={handleOpenBooking} />

        {/* 05: Why Clients Choose Zara's Studio */}
        <WhyChooseUs />

        {/* 06: Google Reviews & Ratings */}
        <ReviewsSection />

        {/* 07: Visual Studio / Treatment Showcase */}
        <GallerySection />

        {/* 08: Studio Location & Maps */}
        <LocationSection />

        {/* 09: Verified Opening Hours Schedule */}
        <OpeningHoursSection onOpenBooking={() => handleOpenBooking()} />

        {/* 10: Final Appointment CTA */}
        <FinalCTA onOpenBooking={() => handleOpenBooking()} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Sticky Bottom Action Bar */}
      <MobileActionBar onOpenBooking={() => handleOpenBooking()} />

      {/* Interactive Booking & Consultation Modal */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={handleCloseBooking}
        initialServiceId={selectedServiceId}
      />
    </div>
  );
}
