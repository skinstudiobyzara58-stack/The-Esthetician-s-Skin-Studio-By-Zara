import React from 'react';

interface LogoProps {
  variant?: 'header' | 'footer' | 'hero';
  className?: string;
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({ variant = 'header', className = '', onClick }) => {
  const isFooter = variant === 'footer';

  return (
    <button
      id="brand-logo-button"
      onClick={onClick || (() => window.scrollTo({ top: 0, behavior: 'smooth' }))}
      className={`group flex items-center gap-3.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#3F6F6A] rounded-xl transition-all ${className}`}
      aria-label="The Esthetician's Skin Studio By Zara - Back to top"
    >
      {/* Sleek Monogram Icon */}
      <div className={`relative flex items-center justify-center rounded-full border border-[#C7AA78]/50 bg-white transition-all duration-300 group-hover:border-[#3F6F6A] group-hover:shadow-xs ${
        isFooter ? 'h-11 w-11 bg-[#F7F3EE]' : 'h-10 w-10'
      }`}>
        <span className="font-editorial text-lg italic font-semibold text-[#332824] tracking-tight group-hover:text-[#3F6F6A] transition-colors">
          ZS
        </span>
        <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-[#8FA58B] border border-white" />
      </div>

      {/* Sleek Editorial Wordmark */}
      <div className="flex flex-col leading-none">
        <span className={`text-[10px] tracking-[0.2em] font-semibold uppercase ${isFooter ? 'text-[#F7F3EE]/60' : 'text-[#332824]/60'}`}>
          The Esthetician's
        </span>
        <span className={`text-lg font-editorial italic font-medium tracking-tight mt-0.5 ${isFooter ? 'text-[#F7F3EE]' : 'text-[#332824]'}`}>
          SKIN STUDIO
        </span>
        <span className="text-[9px] tracking-[0.3em] uppercase text-[#C7AA78] font-bold mt-0.5">
          By Zara
        </span>
      </div>
    </button>
  );
};

