import React, { useState } from 'react';
import { Sparkles, HelpCircle, Phone, ArrowRight } from 'lucide-react';
import { VERIFIED_SERVICES, BUSINESS_DATA } from '../data/studioData';
import { ServiceCard } from './ServiceCard';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface ServicesSectionProps {
  onOpenBooking: (serviceId?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenBooking }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Signature Care', 'Pore & Acne Care', 'Glow & Tone', 'Hydration & Calm', 'Expert Consultation', 'Skin Wellness'];

  const filteredServices = selectedCategory === 'All'
    ? VERIFIED_SERVICES
    : VERIFIED_SERVICES.filter(s => s.category === selectedCategory);

  return (
    <section 
      id="services" 
      className="py-16 sm:py-24 bg-white relative overflow-hidden"
      aria-labelledby="services-heading"
    >
      {/* Soft background accents */}
      <div className="absolute -top-24 right-0 w-96 h-96 rounded-full bg-[#F7F3EE] -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Sleek Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8FA58B]/15 border border-[#8FA58B]/25 text-[10px] font-bold uppercase tracking-widest text-[#3F6F6A]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curated Treatments</span>
          </div>

          <h2 
            id="services-heading"
            className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824]"
          >
            Our Services & Rituals
          </h2>

          <p className="text-xs sm:text-sm text-[#332824]/75 font-normal max-w-md mx-auto leading-relaxed">
            Bespoke aesthetic skincare rituals designed for balance, clarity, and radiant skin health in North Nazimabad, Karachi.
          </p>

          {/* Sleek Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`filter-category-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#332824] text-white shadow-xs'
                    : 'bg-[#F7F3EE] text-[#332824]/70 hover:bg-[#8FA58B]/20 hover:text-[#332824]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Responsive Grid: 3-col desktop, 2-col tablet, 1-col mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onBookService={(id) => onOpenBooking(id)}
            />
          ))}
        </div>

        {/* Custom Consultation Prompt Banner with rounded-3xl and sleek card styling */}
        <div className="mt-12 sm:mt-16 p-6 sm:p-8 rounded-3xl bg-[#F7F3EE] border border-[#332824]/8 flex flex-col md:flex-row items-center justify-between gap-6 sleek-card-shadow">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center flex-shrink-0 text-[#3F6F6A] shadow-xs border border-[#332824]/5">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-editorial text-xl sm:text-2xl font-medium text-[#332824]">
                Unsure which treatment suits your skin?
              </h3>
              <p className="text-xs sm:text-sm text-[#332824]/75">
                Book a personalized skin consultation or chat with Zara's studio directly on WhatsApp at <strong className="text-[#332824]">03082304242</strong> to discuss your skin goals.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0 w-full md:w-auto">
            <a
              id="services-consultation-btn"
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.serviceBooking("Personalized Skin Consultation"))}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Book Skin Consultation on WhatsApp"
              className="flex-1 md:flex-none px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] transition-all shadow-xs text-center cursor-pointer"
            >
              Book Consultation
            </a>
            <a
              id="services-call-btn"
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
              className="flex-1 md:flex-none px-5 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-[#332824] bg-white border border-[#332824]/15 hover:border-[#8FA58B] transition-all flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-[#3F6F6A]" />
              <span>WhatsApp Studio</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};


