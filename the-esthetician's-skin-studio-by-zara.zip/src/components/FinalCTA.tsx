import React from 'react';
import { Calendar, MapPin, Phone, ArrowUpRight, Sparkles } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface FinalCTAProps {
  onOpenBooking: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onOpenBooking }) => {
  return (
    <section 
      id="contact" 
      className="py-16 sm:py-24 bg-white relative overflow-hidden"
      aria-labelledby="final-cta-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Sleek CTA Card Enclosure */}
        <div className="rounded-3xl bg-[#F7F3EE] border border-[#332824]/8 p-8 sm:p-16 text-center space-y-6 sm:space-y-8 sleek-card-shadow relative overflow-hidden">
          
          {/* Subtle Ambient Decorative Accent */}
          <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-[#8FA58B]/15 blur-2xl pointer-events-none -z-0" />
          <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-[#D8B8B5]/20 blur-2xl pointer-events-none -z-0" />

          {/* Subtle Brand Tag */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-[#332824]/8 shadow-xs relative z-10">
            <Sparkles className="w-3.5 h-3.5 text-[#8FA58B]" />
            <span className="text-[10px] font-bold tracking-widest uppercase text-[#332824]">
              Bespoke Aesthetic Care
            </span>
          </div>

          {/* Powerful Editorial Headline */}
          <h2 
            id="final-cta-heading"
            className="font-editorial text-3xl sm:text-5xl lg:text-6xl font-light text-[#332824] leading-tight relative z-10"
          >
            Your Skin Deserves <br />
            <span className="italic font-light text-[#8FA58B]">Thoughtful Care.</span>
          </h2>

          {/* Supporting Copy */}
          <p className="text-xs sm:text-sm text-[#332824]/80 max-w-xl mx-auto font-normal leading-relaxed relative z-10">
            Discover The Esthetician's Skin Studio By Zara in North Nazimabad, Karachi. Schedule your personalized treatment session today.
          </p>

          {/* Sleek CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2 relative z-10">
            {/* Book Appointment CTA */}
            <a
              id="final-book-cta-btn"
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Book an appointment on WhatsApp"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] active:scale-[0.99] transition-all shadow-xs cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </a>

            {/* Directions CTA */}
            <a
              id="final-directions-btn"
              href={BUSINESS_DATA.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-xs font-bold uppercase tracking-wider text-[#332824] bg-white border border-[#332824]/15 hover:border-[#8FA58B] transition-all shadow-xs"
            >
              <MapPin className="w-4 h-4 text-[#C7AA78]" />
              <span>Get Directions</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#332824]/40" />
            </a>

            {/* WhatsApp Direct Chat */}
            <a
              id="final-call-btn"
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full text-xs font-bold uppercase tracking-wider text-[#332824] bg-white/70 border border-[#332824]/10 hover:bg-white transition-colors"
            >
              <Phone className="w-4 h-4 text-[#3F6F6A]" />
              <span>WhatsApp {BUSINESS_DATA.phone}</span>
            </a>
          </div>

          {/* Location & Rating Mini Signature */}
          <div className="pt-8 border-t border-[#332824]/10 flex flex-wrap items-center justify-center gap-6 text-[11px] text-[#332824]/70 relative z-10">
            <span className="font-bold text-[#332824]">4.9 ★ · 42 Reviews</span>
            <span>•</span>
            <span>Ismail Center, Block L, North Nazimabad, Karachi</span>
          </div>

        </div>

      </div>
    </section>
  );
};


