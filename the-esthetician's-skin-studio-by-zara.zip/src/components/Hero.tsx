import React from 'react';
import { Star, MapPin, Calendar, Phone, ArrowUpRight, Sparkles, Navigation } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';
import { getStudioCurrentStatus } from '../utils/timeHelper';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  const status = getStudioCurrentStatus();

  return (
    <section 
      id="hero"
      className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden bg-[#F7F3EE]"
      aria-label="Welcome to The Esthetician's Skin Studio By Zara"
    >
      {/* Subtle ambient gradients */}
      <div className="absolute top-12 left-1/4 -z-10 w-96 h-96 rounded-full bg-[#8FA58B]/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 -z-10 w-80 h-80 rounded-full bg-[#D8B8B5]/15 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* LEFT COLUMN: Sleek Editorial Copy & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Top Micro-Badges & 4.9 Stars */}
            <div className="flex flex-wrap items-center gap-3">
              <span className="bg-[#8FA58B]/20 text-[#3F6F6A] text-[10px] px-3.5 py-1 rounded-full border border-[#8FA58B]/40 font-bold uppercase tracking-wider">
                Premium Care
              </span>

              <div className="flex items-center gap-1.5 bg-white/80 px-3.5 py-1 rounded-full border border-[#332824]/10 shadow-2xs">
                <div className="flex items-center text-[#C7AA78] text-xs">
                  ★ ★ ★ ★ ★
                </div>
                <span className="text-[#332824] text-xs font-semibold ml-1">
                  4.9 · 42 Reviews
                </span>
              </div>

              <span className="text-[11px] font-medium text-[#332824]/60 hidden sm:inline-block">
                North Nazimabad, Karachi
              </span>
            </div>

            {/* Main Editorial Headline in Sleek Interface Style */}
            <div>
              <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-[76px] xl:text-[84px] font-editorial leading-[0.88] italic font-light tracking-tight text-[#332824]">
                Skin That<br />
                <span className="text-[#3F6F6A]">Feels Like You</span>
              </h1>
              
              <p className="mt-4 text-[11px] font-bold tracking-[0.25em] uppercase text-[#C7AA78]">
                The Esthetician's Skin Studio By Zara
              </p>
            </div>

            {/* Sleek Factual Supporting Narrative */}
            <p className="text-sm sm:text-base text-[#332824]/80 max-w-lg font-normal leading-relaxed">
              Experience bespoke aesthetic treatments and personalized skincare in the heart of Karachi. Modern skin health meets quiet luxury at Ismail Center, North Nazimabad.
            </p>

            {/* Sleek Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              {/* Primary Book Button */}
              <a
                id="hero-book-cta-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book an appointment on WhatsApp"
                className="bg-[#332824] text-white px-8 sm:px-10 py-3.5 sm:py-4 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-[#3F6F6A] transition-all shadow-md active:scale-[0.98] cursor-pointer flex items-center gap-2"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Appointment</span>
              </a>

              {/* Get Directions Button */}
              <a
                id="hero-directions-cta-btn"
                href={BUSINESS_DATA.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#3F6F6A] text-white px-6 sm:px-8 py-3.5 sm:py-4 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-[#332824] transition-all shadow-xs flex items-center gap-1.5"
              >
                <MapPin className="w-3.5 h-3.5 text-[#C7AA78]" />
                <span>Get Directions</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-70" />
              </a>

              {/* WhatsApp Contact Button */}
              <a
                id="hero-call-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Contact on WhatsApp"
                className="border border-[#332824]/20 text-[#332824] px-6 sm:px-8 py-3.5 sm:py-4 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-white transition-all flex items-center gap-2"
                title="WhatsApp Direct Line"
              >
                <Phone className="w-3.5 h-3.5 text-[#3F6F6A]" />
                <span>WhatsApp {BUSINESS_DATA.phone}</span>
              </a>
            </div>

            {/* Sleek Micro Status Details */}
            <div className="flex items-center gap-6 pt-4 border-t border-[#332824]/10 text-xs text-[#332824]/70">
              <div className="flex items-center gap-2">
                <span className={`h-2 w-2 rounded-full ${status.isOpen ? 'bg-[#3F6F6A]' : 'bg-[#8FA58B]'}`} />
                <span className="font-medium">{status.statusText} · {status.subText}</span>
              </div>
              <span className="hidden sm:inline text-[#C7AA78]">•</span>
              <span className="hidden sm:inline">Ismail Center, Block L</span>
            </div>

          </div>

          {/* RIGHT COLUMN: Sleek Rounded Visual & Testimonial Hero Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Sleek Outer Rounded Card with crisp white border and deep shadow */}
              <div className="w-full bg-white rounded-[36px] sm:rounded-[44px] p-2.5 sm:p-3 shadow-2xl relative overflow-hidden border-4 border-white sleek-hero-shadow">
                
                {/* Visual Image & Gradient Background */}
                <div className="relative aspect-[4/4.5] w-full rounded-[30px] sm:rounded-[36px] overflow-hidden bg-[#8FA58B]/10">
                  <img
                    src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?q=80&w=1200&auto=format&fit=crop"
                    alt="The Esthetician's Skin Studio By Zara in North Nazimabad"
                    className="w-full h-full object-cover object-center"
                    loading="eager"
                    fetchPriority="high"
                  />
                  
                  {/* Subtle Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#332824]/85 via-[#332824]/20 to-transparent" />
                  
                  {/* Sleek Floating Quote Overlay inside hero visual */}
                  <div className="absolute inset-x-4 bottom-4 p-5 rounded-2xl bg-white/95 backdrop-blur-md border border-white/40 shadow-md text-center space-y-2">
                    <div className="w-12 h-0.5 mx-auto bg-[#8FA58B]" />
                    <p className="font-editorial italic text-lg sm:text-xl text-[#332824] leading-snug">
                      "Personalized care that restores not just your skin health, but your confidence."
                    </p>
                    <p className="text-[10px] uppercase tracking-widest font-bold text-[#3F6F6A]">
                      — Verified Google Review · 4.9 ★ (42 Reviews)
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating Studio Monogram Pill */}
              <div className="absolute -top-3 -right-2 p-3 rounded-2xl bg-white shadow-lg border border-[#332824]/5 flex items-center gap-2.5">
                <span className="font-editorial text-lg italic font-bold text-[#3F6F6A]">ZS</span>
                <span className="text-[10px] uppercase tracking-widest font-bold text-[#332824]">Karachi</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};


