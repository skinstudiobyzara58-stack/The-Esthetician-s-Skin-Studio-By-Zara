import React from 'react';
import { Sparkles, Heart, Shield, Check, ArrowRight } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface AboutStudioProps {
  onOpenBooking: () => void;
}

export const AboutStudio: React.FC<AboutStudioProps> = ({ onOpenBooking }) => {
  return (
    <section 
      id="about" 
      className="py-16 sm:py-24 bg-[#F7F3EE] relative overflow-hidden"
      aria-labelledby="about-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* LEFT: Sleek Visual Composition */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative">
              
              {/* Primary Studio Card Image with rounded-3xl and white border */}
              <div className="relative rounded-3xl overflow-hidden bg-white p-2.5 shadow-xl border border-white">
                <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-[#8FA58B]/10">
                  <img
                    src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1000&auto=format&fit=crop"
                    alt="Serene aesthetic ambiance at The Esthetician's Skin Studio By Zara"
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                </div>
              </div>

              {/* Secondary Overlapping Treatment Detail Shot with rounded-2xl */}
              <div className="hidden sm:block absolute -bottom-6 -right-6 w-48 rounded-2xl overflow-hidden bg-white p-2 shadow-2xl border border-white">
                <div className="aspect-square rounded-xl overflow-hidden bg-[#D8B8B5]/20">
                  <img
                    src="https://images.unsplash.com/photo-1608248597359-253d8650f16f?q=80&w=600&auto=format&fit=crop"
                    alt="Skin care botanical essences"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <p className="mt-2 text-center text-[10px] uppercase font-bold tracking-widest text-[#332824]">
                  Mindful Skincare
                </p>
              </div>

              {/* Decorative luxury badge */}
              <div className="absolute top-4 -left-4 bg-white px-4 py-2 rounded-full shadow-md border border-[#332824]/5 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-[#3F6F6A]" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#332824]">North Nazimabad</span>
              </div>

            </div>
          </div>

          {/* RIGHT: Editorial Narrative & Studio Values */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
            
            {/* Category tag */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold tracking-[0.25em] uppercase text-[#3F6F6A]">
                The Sanctuary
              </span>
              <span className="h-px w-6 bg-[#C7AA78]" />
            </div>

            {/* Editorial Heading */}
            <h2 
              id="about-heading"
              className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824] leading-tight"
            >
              About The Studio <br />
              <span className="italic text-[#8FA58B] font-light">
                Where Skin Health Meets Quiet Luxury.
              </span>
            </h2>

            {/* Story Paragraphs */}
            <div className="space-y-4 text-sm sm:text-base text-[#332824]/80 leading-relaxed font-normal">
              <p>
                Welcome to <strong className="font-semibold text-[#332824]">The Esthetician's Skin Studio By Zara</strong>, situated in the heart of North Nazimabad at Ismail Center, Block L. 
              </p>
              <p>
                Our philosophy is centered on the belief that healthy skin is the foundation of genuine personal confidence. Rather than rushing through one-size-fits-all treatments, every appointment is structured around individualized attention, a calm environment, and thoughtful skincare routines designed for Karachi's climate and everyday lifestyle.
              </p>
              <p>
                Whether you are seeking deep clarifying care, restorative barrier hydration, or a revitalizing glow ritual, the studio provides a relaxing, private space where your skin concerns are heard and handled with precision.
              </p>
            </div>

            {/* Ethos Pills / Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              <div className="flex items-start gap-3 p-4 rounded-2xl bg-white border border-[#332824]/5 shadow-xs">
                <div className="p-2 rounded-xl bg-[#8FA58B]/15 text-[#3F6F6A] mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[11px] font-bold text-[#332824] uppercase tracking-wider">
                    Client-Centered Care
                  </h3>
                  <p className="text-xs text-[#332824]/70 mt-0.5">
                    Unrushed consultations and dedicated one-on-one time.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-2xl bg-white border border-[#332824]/5 shadow-xs">
                <div className="p-2 rounded-xl bg-[#8FA58B]/15 text-[#3F6F6A] mt-0.5">
                  <Check className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[11px] font-bold text-[#332824] uppercase tracking-wider">
                    Calm Private Setting
                  </h3>
                  <p className="text-xs text-[#332824]/70 mt-0.5">
                    Clean, comfortable, and tranquil studio atmosphere.
                  </p>
                </div>
              </div>
            </div>

            {/* CTA action */}
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <a
                id="about-book-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book an appointment on WhatsApp"
                className="bg-[#3F6F6A] text-white px-7 py-3 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-[#332824] transition-all shadow-sm flex items-center gap-2"
              >
                <span>Reserve Your Session</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>

              <a
                id="about-location-link"
                href="#location"
                className="text-xs font-bold uppercase tracking-wider text-[#332824]/80 hover:text-[#3F6F6A] transition-colors"
              >
                Visit Ismail Center →
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};


