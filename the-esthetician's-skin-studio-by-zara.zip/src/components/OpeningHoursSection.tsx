import React from 'react';
import { Clock, AlertCircle, Sparkles, CheckCircle2, Phone, Calendar } from 'lucide-react';
import { WEEKLY_HOURS, BUSINESS_DATA } from '../data/studioData';
import { getStudioCurrentStatus } from '../utils/timeHelper';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface OpeningHoursSectionProps {
  onOpenBooking: () => void;
}

export const OpeningHoursSection: React.FC<OpeningHoursSectionProps> = ({ onOpenBooking }) => {
  const currentStatus = getStudioCurrentStatus();

  return (
    <section 
      id="hours" 
      className="py-16 sm:py-24 bg-[#F7F3EE] relative overflow-hidden"
      aria-labelledby="hours-heading"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8FA58B]/15 border border-[#8FA58B]/25 text-[10px] font-bold uppercase tracking-widest text-[#3F6F6A]">
            <Clock className="w-3.5 h-3.5" />
            <span>Studio Schedule</span>
          </div>

          <h2 
            id="hours-heading"
            className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824]"
          >
            Opening Hours
          </h2>

          <p className="text-xs sm:text-sm text-[#332824]/75 max-w-md mx-auto leading-relaxed">
            Planned around convenient afternoon and evening hours to accommodate your skincare routine.
          </p>

          {/* Real-time Open/Closed Status Banner */}
          <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-white border border-[#332824]/8 shadow-2xs mt-2">
            <span className={`h-2.5 w-2.5 rounded-full ${currentStatus.isOpen ? 'bg-[#3F6F6A] animate-pulse' : 'bg-[#D8B8B5]'}`} />
            <span className="text-xs font-bold text-[#332824]">
              {currentStatus.statusText}
            </span>
            <span className="text-xs text-[#332824]/60 font-medium">
              · {currentStatus.subText}
            </span>
          </div>
        </div>

        {/* Weekly Hours Card with rounded-3xl and sleek layout */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#332824]/8 sleek-card-shadow">
          <div className="divide-y divide-[#F7F3EE]">
            {WEEKLY_HOURS.map((item) => {
              const isToday = item.day === currentStatus.currentDayName;

              return (
                <div
                  key={item.day}
                  id={`schedule-day-${item.day.toLowerCase()}`}
                  className={`py-4 sm:py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-4 transition-colors ${
                    isToday ? 'bg-[#8FA58B]/10 -mx-4 px-4 sm:-mx-6 sm:px-6 rounded-2xl font-semibold' : ''
                  }`}
                >
                  {/* Day Label & Badge */}
                  <div className="flex items-center gap-3">
                    <span className={`text-sm sm:text-base font-medium text-[#332824] ${isToday ? 'font-bold text-[#3F6F6A]' : ''}`}>
                      {item.day}
                    </span>
                    
                    {isToday && (
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-widest bg-[#3F6F6A] text-white">
                        Today
                      </span>
                    )}

                    {item.isSpecialFriday && (
                      <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-[#D8B8B5]/25 text-[#332824]">
                        Extended Friday
                      </span>
                    )}
                  </div>

                  {/* Hours Value & Notes */}
                  <div className="flex flex-col sm:items-end">
                    <span className="font-editorial text-lg sm:text-xl font-medium text-[#332824]">
                      {item.hours}
                    </span>
                    
                    {item.note && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#C7AA78] mt-0.5">
                        <AlertCircle className="w-3 h-3" />
                        <span>{item.note}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Studio scheduling notice & Booking Prompt */}
          <div className="mt-8 pt-6 border-t border-[#332824]/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#332824]/75">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#8FA58B] flex-shrink-0" />
              <span>Appointments are scheduled in advance to ensure dedicated, unrushed attention.</span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <a
                id="hours-book-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book appointment time slot on WhatsApp"
                className="flex-1 sm:flex-none px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] transition-all shadow-xs cursor-pointer text-center"
              >
                Book Time Slot
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};


