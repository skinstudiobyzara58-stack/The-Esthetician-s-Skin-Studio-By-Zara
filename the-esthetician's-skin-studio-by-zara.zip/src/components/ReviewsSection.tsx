import React from 'react';
import { Star, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { GOOGLE_REVIEWS, BUSINESS_DATA } from '../data/studioData';
import { ReviewCard } from './ReviewCard';

export const ReviewsSection: React.FC = () => {
  return (
    <section 
      id="reviews" 
      className="py-16 sm:py-24 bg-white relative overflow-hidden"
      aria-labelledby="reviews-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Section Header & Rating Summary */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-12 sm:mb-16">
          <div className="max-w-xl space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold tracking-[0.25em] uppercase text-[#3F6F6A]">
                Client Experience
              </span>
              <span className="h-px w-6 bg-[#C7AA78]" />
            </div>

            <h2 
              id="reviews-heading"
              className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824]"
            >
              What Our Clients Say
            </h2>

            <p className="text-xs sm:text-sm text-[#332824]/75 leading-relaxed">
              Genuine feedback from clients who have experienced personalized skin treatments at Zara's studio in North Nazimabad.
            </p>
          </div>

          {/* Sleek Rating Summary Box */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 bg-[#F7F3EE] p-5 rounded-3xl border border-[#332824]/6 sleek-card-shadow">
            <div className="text-center sm:text-left pr-4 border-r border-[#332824]/10">
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <span className="font-editorial text-3xl sm:text-4xl font-bold text-[#332824]">4.9</span>
                <div className="text-[#C7AA78] text-sm">
                  ★ ★ ★ ★ ★
                </div>
              </div>
              <p className="text-xs text-[#332824]/70 font-semibold mt-0.5">Based on 42 Google Reviews</p>
            </div>

            <a
              id="view-google-reviews-btn"
              href={BUSINESS_DATA.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-full text-xs font-bold uppercase tracking-wider text-white bg-[#3F6F6A] hover:bg-[#332824] transition-all shadow-xs"
            >
              <span>View On Google Maps</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {GOOGLE_REVIEWS.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>

        {/* Review Verification Note */}
        <div className="mt-8 text-center">
          <p className="text-xs text-[#332824]/60 flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#8FA58B]" />
            <span>Verified 4.9 ★ rating from Google Maps business profile</span>
          </p>
        </div>

      </div>
    </section>
  );
};

