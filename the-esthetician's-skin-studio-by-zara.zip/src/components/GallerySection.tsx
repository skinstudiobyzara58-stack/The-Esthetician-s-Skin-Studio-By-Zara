import React, { useState } from 'react';
import { Sparkles, Maximize2, X } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/studioData';
import { GalleryItem } from '../types';

export const GallerySection: React.FC = () => {
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  return (
    <section 
      id="gallery" 
      className="py-16 sm:py-24 bg-[#F7F3EE] relative overflow-hidden"
      aria-labelledby="gallery-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8FA58B]/15 border border-[#8FA58B]/25 text-[10px] font-bold uppercase tracking-widest text-[#3F6F6A]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Studio Aesthetic</span>
          </div>

          <h2 
            id="gallery-heading"
            className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824]"
          >
            The Studio Experience
          </h2>

          <p className="text-xs sm:text-sm text-[#332824]/75 leading-relaxed max-w-md mx-auto">
            A visual glimpse into our serene treatment suite, mindful rituals, and calming aesthetic environment.
          </p>
        </div>

        {/* Masonry / Bento Gallery Grid with rounded-3xl cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_ITEMS.map((item, index) => (
            <div
              key={item.id}
              id={`gallery-item-${index}`}
              onClick={() => setActiveItem(item)}
              className="group relative aspect-[4/3] rounded-3xl overflow-hidden bg-white border border-[#332824]/8 sleek-card-shadow cursor-pointer"
            >
              <img
                src={item.image}
                alt={item.alt}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              
              {/* Overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#332824]/85 via-[#332824]/25 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] tracking-widest uppercase font-bold text-[#8FA58B]">
                      {item.category}
                    </span>
                    <h3 className="font-editorial text-lg font-medium text-white">
                      {item.title}
                    </h3>
                  </div>
                  <div className="p-2.5 rounded-full bg-white/20 backdrop-blur-md">
                    <Maximize2 className="w-4 h-4 text-white" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {activeItem && (
        <div
          id="gallery-lightbox"
          className="fixed inset-0 z-50 bg-[#332824]/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          onClick={() => setActiveItem(null)}
        >
          <div 
            className="relative max-w-4xl w-full bg-white rounded-3xl overflow-hidden shadow-2xl border border-white/20"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setActiveItem(null)}
              className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-black/60 hover:bg-black text-white transition-colors cursor-pointer"
              aria-label="Close image preview"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="aspect-[16/10] sm:aspect-[16/9] w-full bg-black">
              <img
                src={activeItem.image}
                alt={activeItem.alt}
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-6 bg-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-[#8FA58B] tracking-widest uppercase">
                  {activeItem.category}
                </span>
                <h4 className="font-editorial text-xl font-medium text-[#332824]">
                  {activeItem.title}
                </h4>
              </div>
              <span className="text-xs font-serif italic text-[#332824]/60">The Esthetician's Skin Studio By Zara</span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

