import React from 'react';
import { Phone, Calendar, MapPin } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface MobileActionBarProps {
  onOpenBooking: () => void;
}

export const MobileActionBar: React.FC<MobileActionBarProps> = ({ onOpenBooking }) => {
  return (
    <div 
      id="mobile-sticky-action-bar"
      className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-white/95 backdrop-blur-md border-t border-[#332824]/10 px-4 py-3 shadow-lg"
      role="navigation"
      aria-label="Mobile quick action bar"
    >
      <div className="max-w-md mx-auto grid grid-cols-3 gap-2.5">
        
        {/* Action 1: WhatsApp Chat */}
        <a
          id="mobile-bar-call"
          href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
          className="flex flex-col items-center justify-center py-2 px-2 rounded-2xl text-[#332824] bg-[#F7F3EE] border border-[#332824]/5 hover:bg-[#8FA58B]/20 transition-all text-center"
        >
          <Phone className="w-4 h-4 text-[#3F6F6A] mb-0.5" />
          <span className="text-[10px] font-bold uppercase tracking-wider">WhatsApp</span>
        </a>

        {/* Action 2: Book Appointment */}
        <a
          id="mobile-bar-book"
          href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Book an appointment on WhatsApp"
          className="flex flex-col items-center justify-center py-2 px-2 rounded-2xl text-white bg-[#3F6F6A] hover:bg-[#332824] shadow-xs active:scale-[0.98] transition-all text-center cursor-pointer"
        >
          <Calendar className="w-4 h-4 text-white mb-0.5" />
          <span className="text-[10px] font-bold uppercase tracking-widest">Book Now</span>
        </a>

        {/* Action 3: Directions (Preserved) */}
        <a
          id="mobile-bar-directions"
          href={BUSINESS_DATA.mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center py-2 px-2 rounded-2xl text-[#332824] bg-[#F7F3EE] border border-[#332824]/5 hover:bg-[#8FA58B]/20 transition-all text-center"
        >
          <MapPin className="w-4 h-4 text-[#C7AA78] mb-0.5" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Directions</span>
        </a>

      </div>
    </div>
  );
};


