import React from 'react';
import { Star, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';

export const TrustStrip: React.FC = () => {
  return (
    <section 
      id="trust-strip"
      className="border-y border-[#332824]/10 bg-white py-6 sm:py-8"
      aria-label="Verified Studio Information and Trust Badges"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 items-center">
          
          {/* Trust Point 1: Google Rating */}
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-[#C7AA78]/15 flex items-center justify-center flex-shrink-0 text-[#C7AA78]">
              <Star className="w-5 h-5 fill-[#C7AA78]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-editorial text-lg font-bold text-[#332824]">4.9 ★</span>
                <span className="text-[10px] uppercase tracking-wider font-bold text-[#8FA58B]">Rating</span>
              </div>
              <p className="text-xs text-[#332824]/70 font-medium">42 Google Reviews</p>
            </div>
          </div>

          {/* Trust Point 2: Studio Positioning */}
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-[#8FA58B]/20 flex items-center justify-center flex-shrink-0 text-[#3F6F6A]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#332824]">Professional Skin Studio</p>
              <p className="text-xs text-[#332824]/70">Bespoke Aesthetic Care</p>
            </div>
          </div>

          {/* Trust Point 3: Location */}
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-[#3F6F6A]/10 flex items-center justify-center flex-shrink-0 text-[#3F6F6A]">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#332824]">North Nazimabad</p>
              <p className="text-xs text-[#332824]/70">Ismail Center, Block L</p>
            </div>
          </div>

          {/* Trust Point 4: Personal Attention */}
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-[#D8B8B5]/25 flex items-center justify-center flex-shrink-0 text-[#332824]">
              <CheckCircle2 className="w-5 h-5 text-[#3F6F6A]" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#332824]">1-on-1 Attention</p>
              <p className="text-xs text-[#332824]/70">Dedicated Client Sessions</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

