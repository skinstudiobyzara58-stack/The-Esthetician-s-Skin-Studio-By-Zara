import React from 'react';
import { ArrowRight, Sparkles, CheckCircle } from 'lucide-react';
import { ServiceItem } from '../types';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface ServiceCardProps {
  service: ServiceItem;
  onBookService: (serviceId: string) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service, onBookService }) => {
  const whatsappUrl = getWhatsAppUrl(WHATSAPP_MESSAGES.serviceBooking(service.title));

  return (
    <div
      id={`service-card-${service.id}`}
      className="group flex flex-col justify-between bg-white rounded-3xl overflow-hidden border border-[#332824]/8 sleek-card-shadow sleek-hover"
    >
      {/* Top Image & Category Pill */}
      <div>
        <div className="relative aspect-[16/10] overflow-hidden bg-[#F7F3EE]">
          <img
            src={service.image}
            alt={`${service.title} at The Esthetician's Skin Studio By Zara`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
            loading="lazy"
          />
          {/* Subtle gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#332824]/40 via-transparent to-transparent opacity-50 group-hover:opacity-30 transition-opacity" />
          
          {/* Category Badge */}
          <div className="absolute top-3 left-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase text-[#3F6F6A] bg-white/95 backdrop-blur-md shadow-xs border border-white/40">
              <Sparkles className="w-3 h-3 text-[#8FA58B]" />
              {service.category}
            </span>
          </div>

          {service.featured && (
            <div className="absolute top-3 right-3">
              <span className="px-3 py-1 rounded-full text-[9px] font-bold tracking-widest uppercase text-white bg-[#332824] shadow-xs">
                Popular
              </span>
            </div>
          )}
        </div>

        {/* Content Details */}
        <div className="p-6 sm:p-7">
          <h3 className="font-editorial text-2xl font-medium text-[#332824] leading-snug group-hover:text-[#3F6F6A] transition-colors">
            {service.title}
          </h3>
          
          <p className="mt-2 text-xs sm:text-sm text-[#332824]/75 font-normal leading-relaxed">
            {service.description}
          </p>

          {service.idealFor && (
            <div className="mt-4 pt-3.5 border-t border-[#F7F3EE] flex items-start gap-2 text-xs text-[#332824]/70">
              <CheckCircle className="w-3.5 h-3.5 text-[#8FA58B] mt-0.5 flex-shrink-0" />
              <span><strong>Ideal for:</strong> {service.idealFor}</span>
            </div>
          )}
        </div>
      </div>

      {/* Bottom CTA Area */}
      <div className="px-6 pb-6 sm:px-7 sm:pb-7 pt-0">
        <a
          id={`book-service-btn-${service.id}`}
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Book ${service.title} on WhatsApp`}
          className="w-full py-3 px-5 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
        >
          <span>Book This Service</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};


