import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, Phone, User, Sparkles, CheckCircle2, MapPin, ArrowRight, MessageCircle, Database, Loader2 } from 'lucide-react';
import { VERIFIED_SERVICES, BUSINESS_DATA, WEEKLY_HOURS } from '../data/studioData';
import { BookingFormData } from '../types';
import { getWhatsAppUrl, WHATSAPP_MESSAGES, openWhatsApp } from '../utils/whatsapp';
import { saveAppointmentToSupabase } from '../lib/supabase';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialServiceId?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialServiceId
}) => {
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    phone: '',
    serviceId: initialServiceId || VERIFIED_SERVICES[0].id,
    preferredDate: '',
    preferredTime: '14:00',
    skinConcerns: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [dbSaved, setDbSaved] = useState(false);
  const [confirmationCode, setConfirmationCode] = useState('');

  useEffect(() => {
    if (initialServiceId) {
      setFormData(prev => ({ ...prev, serviceId: initialServiceId }));
    }
  }, [initialServiceId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
      setIsSubmitted(false);
      setIsSaving(false);
      setDbSaved(false);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const selectedService = VERIFIED_SERVICES.find(s => s.id === formData.serviceId) || VERIFIED_SERVICES[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    const code = `ZS-${Math.floor(1000 + Math.random() * 9000)}`;
    setConfirmationCode(code);

    // Save appointment record directly to Supabase
    try {
      const result = await saveAppointmentToSupabase({
        full_name: formData.fullName,
        phone: formData.phone,
        service_id: formData.serviceId,
        service_title: selectedService.title,
        preferred_date: formData.preferredDate,
        preferred_time: formData.preferredTime,
        skin_concerns: formData.skinConcerns,
        confirmation_code: code,
        status: 'pending'
      });
      if (result.success) {
        setDbSaved(true);
      }
    } catch (err) {
      console.warn('Database save attempt caught:', err);
    } finally {
      setIsSaving(false);
      setIsSubmitted(true);

      // Open WhatsApp booking message
      const customMsg = WHATSAPP_MESSAGES.customBooking({
        serviceName: selectedService.title,
        fullName: formData.fullName,
        preferredDate: formData.preferredDate,
        preferredTime: formData.preferredTime,
        notes: formData.skinConcerns
      });
      openWhatsApp(customMsg);
    }
  };

  const bookingWhatsAppUrl = getWhatsAppUrl(WHATSAPP_MESSAGES.customBooking({
    serviceName: selectedService.title,
    fullName: formData.fullName,
    preferredDate: formData.preferredDate,
    preferredTime: formData.preferredTime,
    notes: formData.skinConcerns
  }));

  return (
    <div
      id="booking-modal-overlay"
      className="fixed inset-0 z-50 bg-[#332824]/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div
        className="relative max-w-xl w-full bg-white rounded-3xl overflow-hidden shadow-2xl border border-[#332824]/10 my-8 sleek-card-shadow"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#F7F3EE] p-6 sm:p-8 border-b border-[#332824]/8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold tracking-widest uppercase text-[#3F6F6A]">
                Appointment Request
              </span>
              <span className="h-px w-4 bg-[#C7AA78]" />
            </div>
            <h2 
              id="booking-modal-title"
              className="font-editorial text-2xl sm:text-3xl font-light text-[#332824] mt-1"
            >
              Book Studio Session
            </h2>
          </div>

          <button
            id="close-booking-modal-btn"
            onClick={onClose}
            className="p-2.5 rounded-full text-[#332824]/70 hover:text-[#332824] hover:bg-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              
              {/* Quick direct WhatsApp prompt */}
              <div className="p-4 rounded-2xl bg-[#8FA58B]/15 border border-[#8FA58B]/25 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#3F6F6A] flex-shrink-0" />
                  <span className="text-[#332824]">Prefer to chat immediately on WhatsApp?</span>
                </div>
                <a
                  href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="WhatsApp Zara's Skin Studio"
                  className="font-bold text-[#3F6F6A] hover:underline flex-shrink-0"
                >
                  WhatsApp {BUSINESS_DATA.phone}
                </a>
              </div>

              {/* Service Selection */}
              <div className="space-y-1.5">
                <label htmlFor="service-select" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                  Select Treatment / Service *
                </label>
                <select
                  id="service-select"
                  value={formData.serviceId}
                  onChange={(e) => setFormData({ ...formData, serviceId: e.target.value })}
                  required
                  className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                >
                  {VERIFIED_SERVICES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title} ({s.category})
                    </option>
                  ))}
                </select>
              </div>

              {/* Name & Phone Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="client-name" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                    Full Name *
                  </label>
                  <input
                    id="client-name"
                    type="text"
                    required
                    placeholder="e.g. Ayesha Khan"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] placeholder-[#332824]/40 focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="client-phone" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                    Phone Number *
                  </label>
                  <input
                    id="client-phone"
                    type="tel"
                    required
                    placeholder="e.g. 03001234567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] placeholder-[#332824]/40 focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                  />
                </div>
              </div>

              {/* Preferred Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="preferred-date" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                    Preferred Date *
                  </label>
                  <input
                    id="preferred-date"
                    type="date"
                    required
                    min={new Date().toISOString().split('T')[0]}
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="preferred-time" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                    Preferred Time Slot *
                  </label>
                  <select
                    id="preferred-time"
                    value={formData.preferredTime}
                    onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                    required
                    className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                  >
                    <option value="12:30">12:30 PM (Early Afternoon)</option>
                    <option value="14:00">2:00 PM (Afternoon)</option>
                    <option value="15:30">3:30 PM (Mid Afternoon)</option>
                    <option value="17:00">5:00 PM (Late Afternoon)</option>
                    <option value="18:30">6:30 PM (Evening)</option>
                    <option value="19:30">7:30 PM (Evening / Friday Night)</option>
                  </select>
                </div>
              </div>

              {/* Skin Concerns / Notes */}
              <div className="space-y-1.5">
                <label htmlFor="skin-concerns" className="text-[10px] font-bold text-[#332824] uppercase tracking-widest">
                  Skin Concerns or Notes (Optional)
                </label>
                <textarea
                  id="skin-concerns"
                  rows={2}
                  placeholder="e.g. Sensitivity, acne breakout, barrier dryness, or pre-event glow"
                  value={formData.skinConcerns}
                  onChange={(e) => setFormData({ ...formData, skinConcerns: e.target.value })}
                  className="w-full px-4 py-3 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-xs sm:text-sm text-[#332824] placeholder-[#332824]/40 focus:outline-none focus:ring-2 focus:ring-[#3F6F6A]"
                />
              </div>

              {/* Studio Location Note */}
              <div className="text-[11px] text-[#332824]/60 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#C7AA78] flex-shrink-0" />
                <span>Ismail Center, Block L, North Nazimabad Town, Karachi, 74700</span>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  id="submit-booking-btn"
                  type="submit"
                  disabled={isSaving}
                  className="w-full py-3.5 px-6 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] active:scale-[0.99] transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Saving to Database...</span>
                    </>
                  ) : (
                    <>
                      <Calendar className="w-4 h-4" />
                      <span>Send Appointment Request via WhatsApp</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* Submission Success State */
            <div className="text-center space-y-6 py-4">
              <div className="w-16 h-16 rounded-full bg-[#8FA58B]/20 text-[#3F6F6A] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#8FA58B]/15 text-[#3F6F6A] text-[10px] font-bold uppercase tracking-widest">
                  <Database className="w-3 h-3" />
                  <span>Saved in Studio Database</span>
                </div>
                <h3 className="font-editorial text-2xl sm:text-3xl font-medium text-[#332824]">
                  Thank you, {formData.fullName}!
                </h3>
                <p className="text-xs sm:text-sm text-[#332824]/75 max-w-md mx-auto leading-relaxed">
                  Your appointment request for <strong className="text-[#332824]">{selectedService.title}</strong> has been stored in your studio database under reference code <span className="font-mono font-bold text-[#3F6F6A]">{confirmationCode}</span>.
                </p>
              </div>

              {/* Booking Summary Box */}
              <div className="p-5 rounded-2xl bg-[#F7F3EE] border border-[#332824]/10 text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-[#332824]/60">Service:</span>
                  <span className="font-bold text-[#332824]">{selectedService.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#332824]/60">Preferred Date:</span>
                  <span className="font-bold text-[#332824]">{formData.preferredDate || 'Upcoming available'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#332824]/60">Preferred Time:</span>
                  <span className="font-bold text-[#332824]">{formData.preferredTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#332824]/60">Studio WhatsApp:</span>
                  <span className="font-bold text-[#3F6F6A]">{BUSINESS_DATA.phone}</span>
                </div>
              </div>

              {/* Direct WhatsApp to Confirm */}
              <div className="space-y-3 pt-2">
                <a
                  id="modal-call-confirm-btn"
                  href={bookingWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Confirm on WhatsApp"
                  className="w-full py-3.5 px-6 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] transition-all flex items-center justify-center gap-2 shadow-xs"
                >
                  <Phone className="w-4 h-4" />
                  <span>Open WhatsApp to Confirm Booking</span>
                </a>

                <button
                  id="modal-done-btn"
                  onClick={onClose}
                  className="w-full py-3 px-4 rounded-full text-xs font-bold uppercase tracking-wider text-[#332824]/70 hover:text-[#332824] bg-white border border-[#332824]/10 hover:border-[#8FA58B] transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};



