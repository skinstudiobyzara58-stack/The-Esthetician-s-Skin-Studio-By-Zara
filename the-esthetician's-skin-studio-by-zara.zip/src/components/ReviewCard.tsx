import React from 'react';
import { Star, Quote } from 'lucide-react';
import { ReviewItem } from '../types';

interface ReviewCardProps {
  review: ReviewItem;
}

export const ReviewCard: React.FC<ReviewCardProps> = ({ review }) => {
  return (
    <div
      id={`review-card-${review.id}`}
      className="bg-white rounded-3xl p-7 border border-[#332824]/8 sleek-card-shadow sleek-hover flex flex-col justify-between relative group"
    >
      <div>
        {/* Top Header: Stars & Google Badge */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="flex items-center text-[#C7AA78] text-xs">
            ★ ★ ★ ★ ★
          </div>
          
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#F7F3EE] text-[9px] font-bold tracking-widest text-[#3F6F6A] uppercase border border-[#332824]/5">
            Verified Review
          </span>
        </div>

        {/* Quote text with high-fashion editorial styling */}
        <div className="relative">
          <p className="font-editorial text-lg sm:text-xl text-[#332824] leading-snug italic font-normal">
            "{review.content}"
          </p>
        </div>
      </div>

      {/* Author & Verification Footer */}
      <div className="mt-6 pt-4 border-t border-[#F7F3EE] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#8FA58B]/20 flex items-center justify-center text-xs font-bold text-[#3F6F6A]">
            {review.author.charAt(0)}
          </div>
          <div>
            <p className="text-xs font-bold text-[#332824]">{review.author}</p>
            <p className="text-[10px] uppercase tracking-wider text-[#332824]/50">{review.date}</p>
          </div>
        </div>

        <span className="text-[10px] uppercase tracking-widest font-bold text-[#C7AA78]">
          5.0 Star
        </span>
      </div>
    </div>
  );
};

