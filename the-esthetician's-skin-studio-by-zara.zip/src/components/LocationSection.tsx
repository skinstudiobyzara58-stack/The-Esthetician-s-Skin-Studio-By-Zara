import React from 'react';
import { MapPin, Navigation, Phone, ExternalLink, Building2, Car, Compass } from 'lucide-react';
import { BUSINESS_DATA } from '../data/studioData';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

export const LocationSection: React.FC = () => {
  return (
    <section 
      id="location" 
      className="py-16 sm:py-24 bg-white relative overflow-hidden"
      aria-labelledby="location-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16 space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-[0.25em] uppercase text-[#3F6F6A]">
              Visit The Studio
            </span>
            <span className="h-px w-6 bg-[#C7AA78]" />
          </div>

          <h2 
            id="location-heading"
            className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824]"
          >
            Studio Location & Access
          </h2>

          <p className="text-xs sm:text-sm text-[#332824]/75 leading-relaxed">
            Conveniently located in North Nazimabad Town, Karachi, designed for private, comfortable client visits.
          </p>
        </div>

        {/* Location & Map Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Address & Travel Info Details Card with rounded-3xl */}
          <div className="lg:col-span-5 flex flex-col justify-between p-7 sm:p-8 rounded-3xl bg-[#F7F3EE] border border-[#332824]/8 sleek-card-shadow">
            <div className="space-y-6">
              
              {/* Studio Address Block */}
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-[#3F6F6A] shadow-xs border border-[#332824]/5">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="font-editorial text-2xl sm:text-3xl font-medium text-[#332824]">
                  {BUSINESS_DATA.name}
                </h3>
                <p className="text-xs sm:text-sm font-medium text-[#332824] leading-relaxed">
                  {BUSINESS_DATA.address}
                </p>
              </div>

              {/* Landmark & Access Details */}
              <div className="space-y-3 pt-4 border-t border-[#332824]/10 text-xs text-[#332824]/80">
                <div className="flex items-start gap-3">
                  <Compass className="w-4 h-4 text-[#8FA58B] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#332824] block">Neighborhood:</strong>
                    Block L, North Nazimabad Town, Karachi
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Building2 className="w-4 h-4 text-[#8FA58B] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#332824] block">Building:</strong>
                    Ismail Center
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Car className="w-4 h-4 text-[#8FA58B] flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#332824] block">Accessibility:</strong>
                    Easy street approach and neighborhood drop-off access.
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Info */}
              <div className="p-4 rounded-2xl bg-white border border-[#332824]/5 space-y-1">
                <p className="text-[10px] font-bold text-[#332824]/60 uppercase tracking-widest">
                  Direct Assistance & Directions:
                </p>
                <a 
                  id="location-phone-link"
                  href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="WhatsApp Studio for assistance"
                  className="font-editorial text-xl font-bold text-[#3F6F6A] hover:underline block"
                >
                  {BUSINESS_DATA.phone}
                </a>
              </div>

            </div>

            {/* Action Buttons */}
            <div className="pt-6 mt-6 border-t border-[#332824]/10 flex flex-col sm:flex-row gap-3">
              <a
                id="location-get-directions-btn"
                href={BUSINESS_DATA.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 px-6 rounded-full text-xs font-bold uppercase tracking-widest text-white bg-[#3F6F6A] hover:bg-[#332824] transition-all flex items-center justify-center gap-2 shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Directions</span>
              </a>

              <a
                id="location-call-studio-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
                className="py-3 px-6 rounded-full text-xs font-bold uppercase tracking-wider text-[#332824] bg-white border border-[#332824]/15 hover:border-[#8FA58B] transition-all flex items-center justify-center gap-2"
              >
                <Phone className="w-3.5 h-3.5 text-[#3F6F6A]" />
                <span>WhatsApp Studio</span>
              </a>
            </div>
          </div>

          {/* Interactive Map Visual Presentation with rounded-3xl */}
          <div className="lg:col-span-7 flex flex-col">
            <div className="h-full min-h-[380px] rounded-3xl overflow-hidden border border-[#332824]/8 sleek-card-shadow relative bg-[#F7F3EE]">
              
              {/* Map iframe */}
              <iframe
                title="The Esthetician's Skin Studio By Zara Location Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3617.842777478335!2d67.03714529999999!3d24.9388145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33f20ba8f36c5%3A0xe54d8961c0d45377!2sIsmail%20Center!5e0!3m2!1sen!2s!4v1700000000000!5m2!1sen!2s"
                className="w-full h-full min-h-[380px] border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />

              {/* Floating Map Pin Badge */}
              <div className="absolute top-4 left-4 p-3.5 rounded-2xl bg-white/95 backdrop-blur-md shadow-md border border-[#332824]/10 max-w-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-[#3F6F6A] text-white flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-[#C7AA78]" />
                  </div>
                  <div>
                    <p className="font-editorial text-sm font-bold text-[#332824] leading-tight">
                      Zara's Skin Studio
                    </p>
                    <p className="text-[10px] text-[#332824]/70">
                      Ismail Center, Block L, North Nazimabad
                    </p>
                  </div>
                </div>
              </div>

              {/* Open in Google Maps prompt */}
              <div className="absolute bottom-4 right-4">
                <a
                  href={BUSINESS_DATA.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/95 text-[#332824] text-xs font-bold uppercase tracking-wider shadow-md hover:text-[#3F6F6A] transition-colors border border-[#332824]/10"
                >
                  <span>Open Maps</span>
                  <ExternalLink className="w-3 h-3 text-[#3F6F6A]" />
                </a>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};


