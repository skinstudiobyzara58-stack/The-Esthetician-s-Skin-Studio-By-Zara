import React from 'react';
import { Phone, MapPin, Star, Clock, ExternalLink, ArrowUp, ShieldCheck, Heart } from 'lucide-react';
import { Logo } from './Logo';
import { BUSINESS_DATA, WEEKLY_HOURS } from '../data/studioData';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer 
      id="main-footer"
      className="bg-white border-t border-[#332824]/10 pt-16 pb-24 sm:pb-16 text-[#332824]"
      aria-label="Footer"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-[#332824]/10">
          
          {/* Col 1: Brand & Bio (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <Logo variant="footer" />
            
            <p className="text-xs sm:text-sm text-[#332824]/75 max-w-sm leading-relaxed">
              Boutique skin and aesthetic studio in North Nazimabad, Karachi. Dedicated to personal attention, restorative skincare, and natural confidence.
            </p>

            {/* Google Rating Badge */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#F7F3EE] border border-[#332824]/6 text-xs">
              <div className="text-[#C7AA78] text-xs">
                ★ ★ ★ ★ ★
              </div>
              <span className="font-bold text-[#332824]">4.9 ★</span>
              <span className="text-[#332824]/60">· 42 Google Reviews</span>
            </div>
          </div>

          {/* Col 2: Studio Information & Address (4 cols) */}
          <div className="lg:col-span-4 space-y-3 text-xs sm:text-sm">
            <h3 className="font-editorial text-lg font-medium text-[#332824] uppercase tracking-wider">
              Studio Location
            </h3>
            
            <div className="space-y-2.5 text-[#332824]/80">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#3F6F6A] flex-shrink-0 mt-0.5" />
                <span>{BUSINESS_DATA.address}</span>
              </p>

              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#8FA58B] flex-shrink-0" />
                <a 
                  href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
                  className="font-bold text-[#332824] hover:text-[#3F6F6A] transition-colors"
                >
                  {BUSINESS_DATA.phone}
                </a>
              </p>

              <div className="pt-2">
                <a
                  href={BUSINESS_DATA.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#3F6F6A] hover:underline"
                >
                  <span>Open in Google Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

          {/* Col 3: Hours Summary (3 cols) */}
          <div className="lg:col-span-3 space-y-3 text-xs">
            <h3 className="font-editorial text-lg font-medium text-[#332824] uppercase tracking-wider">
              Studio Hours
            </h3>

            <div className="space-y-1.5 text-[#332824]/75">
              <div className="flex justify-between py-1 border-b border-[#332824]/5">
                <span>Wed – Mon:</span>
                <span className="font-medium text-[#332824]">12:30 PM – 8:00 PM</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#332824]/5">
                <span>Friday:</span>
                <span className="font-medium text-[#332824]">2:00 PM – 9:00 PM</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#332824]/5">
                <span>Tuesday:</span>
                <span className="font-medium text-[#C7AA78]">Hours might differ</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Back to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#332824]/60">
          <p>© {new Date().getFullYear()} The Esthetician's Skin Studio By Zara. All rights reserved.</p>
          
          <div className="flex items-center gap-6">
            <span>North Nazimabad Town, Karachi, Pakistan</span>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1 text-[#332824] hover:text-[#3F6F6A] transition-colors cursor-pointer"
              aria-label="Scroll back to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};


