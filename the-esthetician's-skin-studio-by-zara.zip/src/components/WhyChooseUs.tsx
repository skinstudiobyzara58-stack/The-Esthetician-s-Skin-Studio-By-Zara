import React from 'react';
import { Sparkles, ShieldCheck, MapPin, CalendarCheck, Heart, Star, Check } from 'lucide-react';
import { WHY_CHOOSE_POINTS, BUSINESS_DATA } from '../data/studioData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#8FA58B]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-[#3F6F6A]" />;
      case 'MapPin':
        return <MapPin className="w-5 h-5 text-[#C7AA78]" />;
      case 'CalendarCheck':
        return <CalendarCheck className="w-5 h-5 text-[#3F6F6A]" />;
      case 'Heart':
        return <Heart className="w-5 h-5 text-[#D8B8B5]" />;
      case 'Star':
        return <Star className="w-5 h-5 fill-[#C7AA78] text-[#C7AA78]" />;
      default:
        return <Check className="w-5 h-5 text-[#8FA58B]" />;
    }
  };

  return (
    <section 
      id="why-us"
      className="py-16 sm:py-24 bg-[#F7F3EE] relative overflow-hidden"
      aria-labelledby="why-us-heading"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16 space-y-3">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-[0.25em] uppercase text-[#3F6F6A]">
              Studio Standards
            </span>
            <span className="h-px w-6 bg-[#C7AA78]" />
          </div>

          <h2 
            id="why-us-heading"
            className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-light text-[#332824] leading-tight"
          >
            Why Clients Choose <br />
            <span className="italic font-light text-[#8FA58B]">Zara's Skin Studio</span>
          </h2>

          <p className="text-xs sm:text-sm text-[#332824]/75 font-normal leading-relaxed max-w-lg">
            Thoughtful skincare built on personalized client care, a tranquil North Nazimabad environment, and high standards of comfort and hygiene.
          </p>
        </div>

        {/* 6 Feature Grid with Sleek 3-col rounded-3xl cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_POINTS.map((point, index) => (
            <div
              key={index}
              id={`why-choose-card-${index}`}
              className="bg-white rounded-3xl p-7 border border-[#332824]/6 sleek-card-shadow sleek-hover flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-[#F7F3EE] flex items-center justify-center border border-[#332824]/5">
                  {getIcon(point.iconName)}
                </div>

                <div>
                  <h3 className="font-editorial text-xl font-medium text-[#332824]">
                    {point.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-[#332824]/75 leading-relaxed">
                    {point.description}
                  </p>
                </div>
              </div>

              {/* Minimal aesthetic divider line */}
              <div className="pt-4 mt-4 border-t border-[#F7F3EE] flex items-center justify-between text-[10px] text-[#332824]/50">
                <span className="uppercase tracking-widest font-bold">Studio Standard</span>
                <span className="font-editorial text-sm font-semibold text-[#8FA58B]">0{index + 1}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

