import React, { useState, useEffect } from 'react';
import { Phone, Calendar, Menu, X, MapPin, Star, Clock, MessageCircle } from 'lucide-react';
import { Logo } from './Logo';
import { BUSINESS_DATA } from '../data/studioData';
import { getStudioCurrentStatus } from '../utils/timeHelper';
import { getWhatsAppUrl, WHATSAPP_MESSAGES } from '../utils/whatsapp';

interface HeaderProps {
  onOpenBooking: (serviceId?: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [studioStatus, setStudioStatus] = useState(getStudioCurrentStatus());

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Update live status periodically
    const timer = setInterval(() => {
      setStudioStatus(getStudioCurrentStatus());
    }, 60000);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(timer);
    };
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Location', href: '#location' },
    { name: 'Hours', href: '#hours' }
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      const headerOffset = 80;
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'h-[72px] sm:h-[80px] bg-white/95 backdrop-blur-md shadow-xs border-b border-[#332824]/10'
            : 'h-[76px] sm:h-[80px] bg-white/90 backdrop-blur-xs border-b border-[#332824]/10'
        } flex items-center`}
      >
        <div className="max-w-7xl w-full mx-auto px-4 sm:px-8 lg:px-10">
          <div className="flex items-center justify-between gap-4">
            {/* LEFT: Sleek Brand Wordmark */}
            <div className="flex-shrink-0">
              <Logo />
            </div>

            {/* CENTER: Sleek Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-7 xl:space-x-8 text-[11px] uppercase tracking-widest font-semibold" aria-label="Main Navigation">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  id={`nav-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="text-[#332824]/70 hover:text-[#3F6F6A] transition-colors relative py-1"
                >
                  {link.name}
                </a>
              ))}
            </nav>

            {/* RIGHT: Quick Contact & CTA Buttons */}
            <div className="hidden sm:flex items-center gap-3">
              {/* WhatsApp Contact Pill */}
              <a
                id="header-call-button"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Contact The Esthetician's Skin Studio By Zara on WhatsApp"
                className="inline-flex items-center gap-2 px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#332824] bg-[#F7F3EE] border border-[#332824]/15 rounded-full hover:border-[#8FA58B] hover:bg-white transition-all shadow-2xs"
                title="Chat with Zara on WhatsApp"
              >
                <Phone className="w-3.5 h-3.5 text-[#3F6F6A]" />
                <span>{BUSINESS_DATA.phone}</span>
              </a>

              {/* Primary Book Appointment CTA */}
              <a
                id="header-book-button"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book an appointment on WhatsApp"
                className="inline-flex items-center gap-2 bg-[#3F6F6A] text-white px-6 xl:px-7 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-[#332824] transition-all shadow-md active:scale-[0.98] cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Appointment</span>
              </a>
            </div>

            {/* Mobile Menu Toggle Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <a
                id="mobile-book-header-button"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book an appointment on WhatsApp"
                className="sm:hidden px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-white bg-[#3F6F6A] rounded-full"
              >
                Book
              </a>

              <button
                id="mobile-menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-xl text-[#332824] hover:bg-[#F7F3EE] focus:outline-none focus:ring-2 focus:ring-[#3F6F6A] cursor-pointer"
                aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div 
          id="mobile-nav-drawer"
          className="fixed inset-0 z-30 lg:hidden bg-[#332824]/40 backdrop-blur-xs transition-opacity pt-20"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div 
            className="bg-[#FFFFFF] border-b border-[#332824]/10 px-6 py-6 shadow-xl max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Status indicator */}
            <div className="flex items-center justify-between py-2 px-3 mb-4 bg-[#F7F3EE] rounded-xl text-xs">
              <span className="flex items-center gap-1.5 font-medium text-[#332824]">
                <span className={`h-2 w-2 rounded-full ${studioStatus.isOpen ? 'bg-[#8FA58B] animate-pulse' : 'bg-[#D8B8B5]'}`} />
                {studioStatus.statusText}
              </span>
              <span className="text-[#332824]/70">{studioStatus.subText}</span>
            </div>

            {/* Navigation links */}
            <div className="flex flex-col space-y-3 divide-y divide-[#332824]/5">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  id={`mobile-nav-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="pt-3 text-base font-medium text-[#332824] hover:text-[#3F6F6A] flex items-center justify-between"
                >
                  <span>{link.name}</span>
                  <span className="text-[#8FA58B] text-sm">→</span>
                </a>
              ))}
            </div>

            {/* Contact Actions */}
            <div className="mt-6 pt-6 border-t border-[#332824]/10 space-y-3">
              <a
                id="mobile-drawer-book-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.appointment)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Book an appointment on WhatsApp"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3 px-4 rounded-xl text-sm font-semibold tracking-wide text-white bg-[#3F6F6A] hover:bg-[#345d59] flex items-center justify-center gap-2 shadow-sm"
              >
                <Calendar className="w-4 h-4" />
                <span>Book an Appointment</span>
              </a>

              <a
                id="mobile-drawer-call-btn"
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.generalContact)}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp The Esthetician's Skin Studio By Zara"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-[#332824] bg-[#F7F3EE] border border-[#332824]/10 flex items-center justify-center gap-2 hover:border-[#8FA58B]"
              >
                <Phone className="w-4 h-4 text-[#3F6F6A]" />
                <span>WhatsApp {BUSINESS_DATA.phone}</span>
              </a>

              <a
                id="mobile-drawer-maps-btn"
                href={BUSINESS_DATA.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-xl text-xs font-medium text-[#332824]/70 flex items-center justify-center gap-1.5 hover:text-[#3F6F6A]"
              >
                <MapPin className="w-3.5 h-3.5 text-[#C7AA78]" />
                <span>Ismail Center, Block L, North Nazimabad</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

