export const WHATSAPP_NUMBER = "923082304242";

export const WHATSAPP_MESSAGES = {
  generalContact: "Assalam o Alaikum, I would like to contact The Esthetician's Skin Studio By Zara.",
  appointment: "Assalam o Alaikum, I would like to book an appointment at The Esthetician's Skin Studio By Zara. Please share the available timings.",
  serviceInquiry: "Assalam o Alaikum, I would like more information about the services available at The Esthetician's Skin Studio By Zara.",
  serviceBooking: (serviceName: string) => 
    `Assalam o Alaikum, I am interested in ${serviceName} at The Esthetician's Skin Studio By Zara. I would like to know more and book an appointment.`,
  customBooking: (params: { serviceName: string; fullName?: string; preferredDate?: string; preferredTime?: string; notes?: string }) => {
    let msg = `Assalam o Alaikum, I would like to book an appointment at The Esthetician's Skin Studio By Zara.\n`;
    msg += `• Service: ${params.serviceName}\n`;
    if (params.fullName) msg += `• Name: ${params.fullName}\n`;
    if (params.preferredDate) msg += `• Preferred Date: ${params.preferredDate}\n`;
    if (params.preferredTime) msg += `• Preferred Time: ${params.preferredTime}\n`;
    if (params.notes) msg += `• Notes: ${params.notes}\n`;
    msg += `Please confirm the availability. Thank you!`;
    return msg;
  }
};

/**
 * Generates the clean WhatsApp wa.me URL with properly encoded message text
 */
export function getWhatsAppUrl(message: string = ""): string {
  const baseUrl = `https://wa.me/${WHATSAPP_NUMBER}`;
  if (!message || message.trim() === "") {
    return baseUrl;
  }
  return `${baseUrl}?text=${encodeURIComponent(message.trim())}`;
}

/**
 * Helper to open WhatsApp URL in a new window/tab safely
 */
export function openWhatsApp(message: string = ""): void {
  const url = getWhatsAppUrl(message);
  window.open(url, '_blank', 'noopener,noreferrer');
}
