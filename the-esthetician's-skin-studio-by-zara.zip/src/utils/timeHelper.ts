import { WEEKLY_HOURS } from '../data/studioData';

export interface StudioCurrentStatus {
  isOpen: boolean;
  statusText: string;
  subText: string;
  currentDayName: string;
  isTodayTuesday: boolean;
}

/**
 * Calculates current studio status based on Asia/Karachi timezone (UTC+5)
 */
export function getStudioCurrentStatus(): StudioCurrentStatus {
  // Get time in Karachi (Asia/Karachi UTC+5)
  const now = new Date();
  
  // Format to Karachi time
  const karachiDateString = now.toLocaleString("en-US", { timeZone: "Asia/Karachi" });
  const karachiDate = new Date(karachiDateString);
  
  const dayIndex = karachiDate.getDay(); // 0 = Sunday, 1 = Monday, ... 6 = Saturday
  const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const currentDayName = daysOfWeek[dayIndex];
  
  const currentMinutes = karachiDate.getHours() * 60 + karachiDate.getMinutes();
  
  const todaySchedule = WEEKLY_HOURS.find(item => item.day === currentDayName) || WEEKLY_HOURS[0];
  
  const isOpen = currentMinutes >= todaySchedule.openMinutes && currentMinutes < todaySchedule.closeMinutes;
  const isTodayTuesday = currentDayName === "Tuesday";
  
  let statusText = "Closed Now";
  let subText = `Opens at ${todaySchedule.hours.split('–')[0].trim()}`;
  
  if (isOpen) {
    statusText = "Open Today";
    subText = `Open until ${todaySchedule.hours.split('–')[1].trim()}`;
  } else if (currentMinutes >= todaySchedule.closeMinutes) {
    statusText = "Closed for the day";
    // Find next day schedule
    const nextDayIndex = (dayIndex + 1) % 7;
    const nextDayName = daysOfWeek[nextDayIndex];
    const nextSchedule = WEEKLY_HOURS.find(item => item.day === nextDayName);
    subText = `Opens tomorrow (${nextDayName}) at ${nextSchedule?.hours.split('–')[0].trim() || '12:30 PM'}`;
  }
  
  return {
    isOpen,
    statusText,
    subText,
    currentDayName,
    isTodayTuesday
  };
}
