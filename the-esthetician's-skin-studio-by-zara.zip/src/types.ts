export interface BusinessInfo {
  name: string;
  shortName: string;
  tagline: string;
  rating: number;
  reviewCount: number;
  ratingDisplay: string;
  phone: string;
  phoneRaw: string;
  address: string;
  addressShort: string;
  mapsUrl: string;
  city: string;
  neighborhood: string;
  postalCode: string;
  country: string;
}

export interface DaySchedule {
  day: string;
  hours: string;
  note?: string;
  openMinutes: number; // e.g. 12:30 PM = 12*60 + 30 = 750
  closeMinutes: number; // e.g. 8:00 PM = 20*60 = 1200
  isSpecialFriday?: boolean;
}

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  featured?: boolean;
  idealFor?: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  date: string;
  content: string;
  source: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  alt: string;
}

export interface BookingFormData {
  fullName: string;
  phone: string;
  serviceId: string;
  preferredDate: string;
  preferredTime: string;
  skinConcerns: string;
}
